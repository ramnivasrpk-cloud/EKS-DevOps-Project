# Production Grade DevOps Project

## Stack
- AWS EKS
- Terraform
- Docker
- Kubernetes
- GitHub Actions
- Jenkins
- Prometheus
- Grafana

## Deployment

1. Run Terraform
2. Configure kubectl
3. Install ingress controller
4. Deploy application
5. Configure CI/CD
