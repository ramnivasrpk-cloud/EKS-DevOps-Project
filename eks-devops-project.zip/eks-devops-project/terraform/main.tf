terraform {
  backend "s3" {
    bucket = "eks-terraform-state-bucket"
    key    = "eks/terraform.tfstate"
    region = "ap-south-1"
  }
}
